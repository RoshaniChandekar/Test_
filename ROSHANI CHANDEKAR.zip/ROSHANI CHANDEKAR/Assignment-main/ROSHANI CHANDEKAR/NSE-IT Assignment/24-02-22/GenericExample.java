public class GenericExample {

        public void main(String args[]) {
            Gen<String> g = new Gen("Hello");
            g.showType();
        }
    }