package com.examples.postservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
